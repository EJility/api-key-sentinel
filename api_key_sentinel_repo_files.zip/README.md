# API Key Sentinel Landing Page

This repo powers the free GitHub Pages site for **API Key Sentinel v1.0.6**.

## URL
Once Pages is enabled:
`https://<your-username>.github.io/api-key-sentinel/`

## Edit
- Modify `index.html` for copy/branding.
- Replace the button link with your Acquire.com listing once live.

## License
MIT — use freely.
